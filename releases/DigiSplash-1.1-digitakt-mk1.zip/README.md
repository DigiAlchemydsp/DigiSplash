# DigiSplash 1.1 - Digitakt mk1, OS 1.53

Prebuilt boot-splash mods (`.elemod`, elekloader format 2). Elemods only.

    elemods/<name>.elemod     install these

Needs the matching core mod: core-2.1 (`core` and `core-dn1` in elekloader).
Install one draw mod at a time - they hook the same intro present sites.
`rare-splash` patches a different instruction and can be combined, but a draw
mod hides it.

Install with elekloader:

    python -m elekloader.patch --stock <stock .syx> \
        --mod <core>.elemod --mod elemods/<name>.elemod --out out.syx --version 2.0x

Recovery: hold FUNC while powering on, then send the stock .syx.

The .elemod files contain the mod's own bytes (including any packed frames);
no Elektron firmware. See LICENSE (GPL-2.0-or-later).
